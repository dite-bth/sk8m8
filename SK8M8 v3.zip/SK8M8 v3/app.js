var start = false;
var expanded = false;

$(document).ready(function () {

	$("#backButton").hide();
	$("#startPhoton").hide();
	$("#info").hide();
	$("#loader").hide();


	$('#box').click(function() {
			if (start == false) {
				$(this).toggleClass('clicked');
				$(this).text('Start Session');
				$(this).css('opacity', '0.8');

				start = true;
				$("#history").hide();
				$("#about").hide();
				setTimeout(function() {
					$("#box").css('font-size', '80px');
					$("#box").text("^");
					$("#backButton").show();
					$("#startPhoton").show();
					$("#info").show();
				}, 2000);
				/*setTimeout(function() {
                  $("#box").append("<div id='backBtn' class='btn'>Back</div>");
                  $("#box").append("<div id='runBtn' class='btn'>Run</div>");
                  $(".btn").mouseover(function(){
						$(this).css('opacity', '0.8');
					});
					$(".btn").mouseout(function(){
						$(this).css("opacity", "0.6");
					});

					$('#backBtn').click(function() {
					location.reload();
					//$(this).remove();
					});
					$('#runBtn').click(function() {
						$("#box").append("<div id='loader'></div>");
						$("#runBtn").text("3");

						setTimeout(function() {
							$("#runBtn").text("2");
							}, 1000);
						setTimeout(function() {
							$("#runBtn").text("1");
							}, 2000);
						setTimeout(function() {
							$("#loader").remove();
							$("#runBtn").remove();
							}, 3000);
					});

            }, 2000);*/
				
			}
			else {

				
			}
	});
	

	$(".mainButtons").mouseover(function(){
		if (start == false) {
			$(this).css('opacity', '0.8');
		}
	});
	$(".mainButtons").mouseout(function(){
		if (start == false) {
			$(this).css("opacity", "0.6");
		}
	});

	$(".buttons").mouseover(function(){
		
		$(this).css('opacity', '1.0');
		
	});
	$(".buttons").mouseout(function(){
		
		$(this).css("opacity", "0.6");
		
	});

	$('#startPhoton').click(function() {
		$(this).hide();
		$("#loader").show();
		setTimeout(function() {
			
		}, 1000);
		setTimeout(function() {
			
		}, 2000);
		setTimeout(function() {
			$("#loader").hide();
			$.ajax({url: 'RunPhoton.php'});
		}, 3000);
		
		setTimeout(function() {
			$.ajax({
   			url: 'AirtimeCalculator.php',
   			success: function (response) {
     		$("#infoText").text("Your airtime was " + response + ".");
   				}
			});
		}, 11000);

	});
});
