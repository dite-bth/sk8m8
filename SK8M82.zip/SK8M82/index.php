<!DOCTYPE html>

<html>

<head>

  <link rel="stylesheet" type="text/css" href="stylesheet.css">

  <meta charset="UTF-8">

  <meta name="viewport" content="width=device-width, initial-scale=1">

  <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>

  <script src="app.js"></script>

  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

  <title>SK8M8</title>

</head>

<body>

  <br><h1>SK8M8</h1></br>

  <br><div id="box">START SESSION</div></br>

  <p>Hej</p>

</body>

</html>
