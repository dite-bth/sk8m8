var start = false;

$(document).ready(function () {

	$('#box').on('click', function() {
	    $(this).on('clicked');
			if (start) {
				$(this).text('Start Session');
				start = false;
			}
			else {
			$(this).text('Test');
			start = true;
			}
	});
});
