<!DOCTYPE html>
<html>
<head><title>Test</title></head>
<body>

	<p>Test</p>
	<?php
		$testArray = array(73.00, 73.00, 73.00, 73.00, 77.00, 127.00, 127.00, 127.00, 52.00, 16.00, -12.00,-19.00, -4.00, -16.00, 11.00, 29.00, 43.00, 127.00, 127.00, 59.00, 72.00, 73.00, 73.00, 73.00);
		$inAir = false;
		$airTime = 0;
		for ($i = 0; $i < count($testArray); $i++) {
			if ($testArray[i] == 73.00) {
				if ($inAir) {
					$inAir = false;
					break;
				}
			}
			else if ($testArray[i] != 73.00) {
				$inAir = true;
				$airTime++;
			}
		}
		$result = $airTime / 20;

	?>
	<p>The result is <?php echo $result; ?> seconds.</p>

</body>
</html>
