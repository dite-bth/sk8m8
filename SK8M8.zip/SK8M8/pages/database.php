<head>

  <link rel="stylesheet" type="text/css" href="../stylesheet.css">

  <title>Start Session</title>

    <body>

      <br><a href="../index.html"><h1>SK8M8</h1></a></br>

      <br><a href="https://api.particle.io/v1/devices/3d003d000a47343432313031/getData?access_token=997c813e54c1d6e7fc6742846075369f8586dada&format=raw"><button>START</button></a></br>

      <br><a href="#"><button>STOP</button></a></br>

      <?php
      $servername = "localhost";
      $username = "uwamp";
      $password = "Nikolas";

     // Create connection
     $conn = mysqli_connect($servername, $username, $password);

     // Check connection
     if (!$conn) {
         die("Connection failed: " . mysqli_connect_error());
     }
     echo "Connected successfully";
     ?>

    </body>

</head>
