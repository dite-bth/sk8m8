<!DOCTYPE html>

<html>

<head>

  <link rel="stylesheet" type="text/css" href="../stylesheet.css">

  <title>Start Session</title>

</head>

    <body>

      <br><a href="../index.html"><h1>SK8M8</h1></a></br>
<!-- https://api.particle.io/v1/devices/3d003d000a47343432313031/led?access_token=997c813e54c1d6e7fc6742846075369f8586dada" -->
      <center>
      <form action="startsession.php" method="POST">
        <input type="hidden" name="start_session" value="on">
        <input type="submit" value="Start">
      </form>
      </center>

      <br><br></br></br><p div class="airtime">Airtime:</p>

      <?php
        if(isset($_POST["session_start"]) && $_POST["session_start"] == true) {
          $ curl 'https://api.particle.io/v1/devices/3d003d000a47343432313031/gong -d arg="on" -d access_token=997c813e54c1d6e7fc6742846075369f8586dada';
        }
    		$testArray = array();
    		//Hämtar texten som skrivs av vår Particle.
    		$str = file_get_contents('https://api.particle.io/v1/devices/3d003d000a47343432313031/getData?access_token=997c813e54c1d6e7fc6742846075369f8586dada&format=raw');
    		//Skapar en array genom att dela upp alla nummer med hjälp av kommatecken.
    		$testArray = explode(",", $str);

    		$inAir = false;
    		$jumps = 0;
    		$airTime = 0;
    		$failSafe = 0;
    		$results = array();
    		for ($i = 0; $i < count($testArray); $i++) {
    			if (intval($testArray[$i]) > 70 && intval($testArray[$i]) < 76) {
    				if ($inAir) {
    					$failSafe++;
    					if ($failSafe == 3) {
    						$inAir = false;
    						$failSafe = 0;
    						if ($airTime > 4) {
    							$results[$jumps] = ($airTime + 1) / 20;
    							$jumps++;
    						}
    						$airTime = 0;
    					}

    				}
    			}
    			else if (intval($testArray[$i]) < 70 || intval($testArray[$i]) > 76) {
    				$inAir = true;
    				$airTime++;
    			}
    		}
    		//Räknar hopp och slår ihop resultaten (punkter funkar som plus i PHP)
    		switch ($jumps) {
    			case '1':
    				$result = $results[0];
    				break;
    			case '2':
    				$result = $results[0] . " and " . $results[1];
    				break;
    				case '3':
    				$result = $results[0] . ", " . $results[1] . " and " . $results[2];
    				break;
    			default:
    				$result = "0";
    				break;
    		}

    ?>

      <p div class="airtime"><?php echo $result; ?> seconds</p>

    </body>
