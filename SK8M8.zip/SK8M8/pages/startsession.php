<!DOCTYPE html>

<html>

<head>

  <link rel="stylesheet" type="text/css" href="../stylesheet.css">

  <title>Start Session</title>

    <body>

      <br><a href="../index.html"><h1>SK8M8</h1></a></br>

      <br><a href="https://api.particle.io/v1/devices/3d003d000a47343432313031/getData?access_token=997c813e54c1d6e7fc6742846075369f8586dada&format=raw"><button>START</button></a></br>

      <br><a href="#"><button>STOP</button></a></br>

      <br><br></br></br><p div class="airtime">Airtime:</p>

      <?php
        $testArray = array(73.00, 73.00, 73.00, 73.00, 77.00, 127.00, 127.00, 127.00, 52.00, 16.00, -12.00,-19.00, -4.00, -16.00, 11.00, 29.00, 43.00, 127.00, 127.00, 59.00, 72.00, 73.00, 73.00, 73.00);
        $inAir = false;
        $airTime = 0;
        for ($i = 0; $i < count($testArray); $i++) {
          if ($testArray[i] == 73.00) {
            if ($inAir) {
              $inAir = false;
              break;
            }
          }
          else if ($testArray[i] != 73.00) {
            $inAir = true;
            $airTime++;
          }
        }
        $result = $airTime / 20;

      ?>

      <p div class="airtime"><?php echo $result; ?> seconds</p>

    </body>

</head>
