var start = false;

$(document).ready(function () {

	$('#startPhoton').hide();
	$('#info').hide();
	$('#backButton').hide();

	$('#box').on('click', function() {
			if (start == false) {
				$(this).toggleClass('clicked');
				$(this).text('Start Session');
				start = true;
			}
			else {
			}
	});
	$('#box').on('click', function() {
		$('#startPhoton').show();
		$('#info').show();
		$('#backButton').show();
});
});
